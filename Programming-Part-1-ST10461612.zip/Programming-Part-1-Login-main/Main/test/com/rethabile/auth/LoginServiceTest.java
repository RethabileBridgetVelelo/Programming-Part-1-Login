package com.rethabile.auth;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginServiceTest {

    @Test
    public void testCheckUserNameValid() {
        LoginService service = new LoginService();
        assertTrue(service.checkUserName("u_ser"));
    }

    @Test
    public void testCheckUserNameInvalid() {
        LoginService service = new LoginService();
        assertFalse(service.checkUserName("user")); // No underscore
        assertFalse(service.checkUserName("very_long_username")); // Too long
    }

    @Test
    public void testCheckPasswordComplexityValid() {
        LoginService service = new LoginService();
        assertTrue(service.checkPasswordComplexity("Passw0rd!"));
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {
        LoginService service = new LoginService();
        assertFalse(service.checkPasswordComplexity("weak")); // Too short
        assertFalse(service.checkPasswordComplexity("password")); // No uppercase/number/special
    }

    @Test
    public void testCheckCellPhoneNumberValid() {
        LoginService service = new LoginService();
        assertTrue(service.checkCellPhoneNumber("+27123456789"));
    }

    @Test
    public void testCheckCellPhoneNumberInvalid() {
        LoginService service = new LoginService();
        assertFalse(service.checkCellPhoneNumber("0712345678")); // Wrong format
        assertFalse(service.checkCellPhoneNumber("+2712345678")); // Too short
    }

    @Test
    public void testRegisterUserValid() {
        LoginService service = new LoginService();
        User user = new User("John", "Doe", "+27123456789", "j_ohn", "Passw0rd!");
        assertEquals("User registered successfully!", service.registerUser(user));
    }

    @Test
    public void testLoginUserValid() {
        LoginService service = new LoginService();
        User user = new User("John", "Doe", "+27123456789", "j_ohn", "Passw0rd!");
        service.registerUser(user);
        assertTrue(service.loginUser("j_ohn", "Passw0rd!"));
    }
}