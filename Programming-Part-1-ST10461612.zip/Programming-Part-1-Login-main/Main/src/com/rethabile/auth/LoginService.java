package com.rethabile.auth;

public class LoginService {
    private User registeredUser;

    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        return password != null && 
               password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[@#$%!].*");
    }

    public boolean checkCellPhoneNumber(String phone) {
        return phone != null && phone.matches("^\\+27\\d{9}$");
    }

    public String registerUser(User user) {
        if (!checkUserName(user.getUsername())) {
            return "Username must contain '_' and be ≤5 characters";
        }
        if (!checkPasswordComplexity(user.getPassword())) {
            return "Password must be ≥8 chars with uppercase, number, and special character";
        }
        if (!checkCellPhoneNumber(user.getPhone())) {
            return "Phone must be +27 followed by 9 digits";
        }
        registeredUser = user;
        return "User registered successfully!";
    }

    public boolean loginUser(String username, String password) {
        return registeredUser != null &&
               registeredUser.getUsername().equals(username) &&
               registeredUser.getPassword().equals(password);
    }

    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + registeredUser.getFirstName() + " " + registeredUser.getSurname() + ", it is great to see you again.";
        } else {
            return "Username or password incorrect";
        }
    }
}